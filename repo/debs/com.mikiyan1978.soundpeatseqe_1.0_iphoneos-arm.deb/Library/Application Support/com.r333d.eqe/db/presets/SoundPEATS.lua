return {
    {
        name = "preamp",
        gain = 3.1164529323578,
    },
    {
        name = "eq",
        frequency = 31,
        Q = 1,
        gain = 4.6451612903226,
    },
    {
        name = "eq",
        frequency = 60,
        Q = 1,
        gain = 4.6451612903226,
    },
    {
        name = "eq",
        frequency = 170,
        Q = 1,
        gain = 3.4838709677419,
    },
    {
        name = "eq",
        frequency = 310,
        Q = 1,
        gain = 0.0,
    },
    {
        name = "eq",
        frequency = 600,
        Q = 1,
        gain = -3.8709677419355,
    },
    {
        name = "eq",
        frequency = 1000,
        Q = 1,
        gain = -3.4838709677419,
    },
    {
        name = "eq",
        frequency = 3000,
        Q = 1,
        gain = 0.0,
    },
    {
        name = "eq",
        frequency = 6000,
        Q = 1,
        gain = 4.6451612903226,
    },
    {
        name = "eq",
        frequency = 12000,
        Q = 2,
        gain = 5.8064516129032,
    },
    {
        name = "eq",
        frequency = 14000,
        Q = 2,
        gain = 5.8064516129032,
    },
    {
        name = "eq",
        frequency = 16000,
        Q = 2,
        gain = 5.4193548387097,
    },
}