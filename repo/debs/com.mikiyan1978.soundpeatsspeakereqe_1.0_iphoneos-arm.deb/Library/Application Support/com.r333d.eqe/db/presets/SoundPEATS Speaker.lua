return {
    {
        name = "preamp",
        gain = -8,
    },
    {
        name = "eq",
        frequency = 30,
        Q = 1,
        gain = 2.4,
    },
    {
        name = "eq",
        frequency = 60,
        Q = 0.8,
        gain = 2.0,
    },
    {
        name = "eq",
        frequency = 100,
        Q = 1,
        gain = 10.0,
    },
    {
        name = "eq",
        frequency = 170,
        Q = 0.6,
        gain = 2.3,
    },
    {
        name = "eq",
        frequency = 310,
        Q = 1,
        gain = 3.8,
    },
    {
        name = "eq",
        frequency = 600,
        Q = 1,
        gain = 4.0,
    },
    {
        name = "eq",
        frequency = 1000,
        Q = 1,
        gain = 4.5,
    },
    {
        name = "eq",
        frequency = 3000,
        Q = 1,
        gain = 3.5,
    },
    {
        name = "eq",
        frequency = 6000,
        Q = 1,
        gain = 3.0,
    },
    {
        name = "eq",
        frequency = 9000.0,
        Q = 2,
        gain = 8.0,
    },
    {
        name = "eq",
        frequency = 12000,
        Q = 2,
        gain = 10.0,
    },
    {
        name = "eq",
        frequency = 14000,
        Q = 1.7,
        gain = 4.0,
    },
    {
        name = "eq",
        frequency = 16000,
        Q = 1.3,
        gain = 6.0,
    },
}